// Write your import statements here if necessary

export const mrsPotatoHeadQuotes = {
        
                "hello": "Hi, I'm Mrs. Potato Head! Pleasure to meet you.",
                "bye": "Bye, Sweet Potato!"
        
       }