// Write your import statements here if necessary
import Game from './game.js';

window.onload = () => {
    const game = new Game();
    game.start();
};
